"grande clubw"

def main():
    print("Viva ao Chaves")

if __name__ == "__main__":
    main()